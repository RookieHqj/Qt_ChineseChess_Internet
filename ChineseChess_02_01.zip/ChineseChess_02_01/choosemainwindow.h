#ifndef CHOOSEMAINWINDOW_H
#define CHOOSEMAINWINDOW_H

#include <QWidget>
#include "chessboard.h"
#include "machinegame.h"
#include "networkgame.h"

class ChooseMainWindow : public QWidget
{
    Q_OBJECT

public:
    explicit ChooseMainWindow(int nChooseGame,QWidget *parent = nullptr);
    ~ChooseMainWindow();


    int m_nChooseGame;

    ChessBoard * m_p1;
    MachineGame * m_p2;
    NetworkGame * m_p3;

signals:

public slots:
};

#endif // CHOOSEMAINWINDOW_H
