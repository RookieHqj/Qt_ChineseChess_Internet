#include "chessstep.h"

ChessStep::ChessStep(QObject *parent) : QObject(parent)
{

}

ChessStep::~ChessStep()
{

}

