#include "chessboard.h"
#include <QApplication>

#include "selectgamemode.h"
#include "choosemainwindow.h"

int main(int argc, char *argv[])
{
    QApplication a(argc, argv);

    SelectGameMode dlg;
    if(dlg.exec() != QDialog::Accepted)
    {
        return 0;
    }

    ChooseMainWindow wnd(dlg.m_nSelect);

    return a.exec();
}
